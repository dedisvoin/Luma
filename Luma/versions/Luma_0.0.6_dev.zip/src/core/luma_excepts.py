from colorama import Fore

class LumaExceptionType:
    PARSER = f'[ {Fore.CYAN}parser{Fore.RESET} ]'


class BaseLumaException(BaseException):
    def __init__(self, except_type: LumaExceptionType, text: str) -> None:
        self.__except_type = except_type
        self.__text = text

    def __str__(self) -> str:
        return f'''Exeption {self.__except_type}
{self.__text}
'''
