from src.core import tokens
from src.parse import nodes
from src.core import memory
from src.core import luma_excepts

class Parser:
    def __init__(self) -> None:
        self.__tokens = []
        self.__nodes = []
        self.__pos = 0

    @property
    def code_tokens(self) -> list[tokens.Token]:
        return self.__tokens
    
    @code_tokens.setter
    def code_tokens(self, tokens: list[tokens.Token]):
        self.__tokens = tokens

    def next_token(self):
        self.__pos += 1

    def before_token(self):
        self.__pos -= 1

    def get_token(self, offset: int = 0):
        return self.__tokens [self.__pos + offset]
    
    def get_token_signature(self, offset: int = 0) -> tokens.TokenSignature:
        return self.get_token(offset).signature
    
    def get_token_value(self, offset: int = 0) -> str:
        return self.get_token(offset).value
    
    def get_token_position(self, offset: int = 0) -> tokens.TokenPosition:
        return self.get_token(offset).position
    
    def is_token_signature(self, signature: tokens.TokenSignature, offset: int = 0) -> bool:
        return self.get_token_signature(offset) == signature
    
    def match_token_signature(self, signature: tokens.TokenSignature):
        if self.is_token_signature(signature):
            self.next_token()
            return True
        return False
    
    def match_token_signatures(self, signatures: list[tokens.TokenSignature]) -> bool:
        for signature in signatures:
            if self.is_token_signature(signature):
                self.next_token()
                return True
        return False
    
    def match_and_wait(self, signature: tokens.TokenSignature):
        if self.match_and_wait(signature):
            ...
        else:
            raise luma_excepts.BaseLumaException(luma_excepts.LumaExceptionType.PARSER, f'Waited {signature} signature')
    
    def STATEMENT_VARIABLE_SET(self):
        if self.is_token_signature(tokens.TokenSignature.KEYWORD_VAR) or self.is_token_signature(tokens.TokenSignature.KEYWORD_VAL):
            self.match_token_signatures([tokens.TokenSignature.KEYWORD_VAR, tokens.TokenSignature.KEYWORD_VAL])
            mutable = memory.MemoryObjectTypes.mutable if self.match_token_signature(tokens.TokenSignature.KEYWORD_MUT) else memory.MemoryObjectTypes.unmutable
            name = self.get_token_value()
            self.match_token_signature(tokens.TokenSignature.WORD)
            expression = self.parse_expression()
            return nodes.Statements.NodeVariableSet(name, mutable, expression)
            
            

    def parse_statement(self):
        self.STATEMENT_VARIABLE_SET()

    def parse_expression(self):
        return ...

    def generate_ast(self):
        while self.get_token_signature() != tokens.TokenSignature.EOF:
            self.__nodes.append(self.parse_statements)
            self.next_token()