from colorama import Fore

from src.analize import tokenizer, loader
from src.parse import parser
from src.core import tokens

from src.debug import debug
from src.debug import tokenizer as debug_tokenizer


class Compiler:
    def __init__(self, debuging: bool, file: str) -> None:
        self.debug_ = debuging
        self.file_ = file

        debug.set_debug_log(True)

        def print_tokens(tokens: list[tokens.Token]):
            for token in tokens:
                print(f' token: {Fore.YELLOW}{token.value:>30}{Fore.RESET}   |   pos: {str(token.position):>70}   |   name: {Fore.MAGENTA}{token.signature:>40}{Fore.RESET}')
        debug_tokenizer.debug_tokens_first_stage.out_funct = print_tokens
        debug_tokenizer.debug_tokens_second_stage.out_funct = print_tokens

        

    def load(self):
        self.code_file_ = loader.LoadLumaFile(self.file_)
        self.tokenizer_ = tokenizer.Tokenizer()
        self.tokenizer_.file = self.code_file_
        self.parser_ = parser.Parser()
        
    
    def tokenize(self):
        self.tokenizer_.tokenize()
        debug_tokenizer.debug_tokens_first_stage(self.tokenizer_.basic_tokens)
        self.tokenizer_.convert_signatures()
        debug_tokenizer.debug_tokens_second_stage(self.tokenizer_.standert_tokens)
        self.parser_.code_tokens = self.tokenizer_.standert_tokens

    def parse(self):
        self.parser_.generate_ast()


LC = Compiler(True, r'compiler\main.lm')
LC.load()
LC.tokenize()
LC.parse()