from colorama import Fore
from src.core import tokens
from src.parse import nodes
from src.core import memory
from src.core import luma_excepts
from src.analize import loader

class Parser:
    def __init__(self) -> None:
        self.__tokens = []
        self.__nodes = []
        self.__pos = 0
        self.__run_time_memory = memory.Memory()
        self.__file = None

    @property
    def file(self) -> loader.LumaFile:
        return self.__file
    
    @file.setter
    def file(self, value: loader.LumaFile):
        self.__file = value

    @property
    def nodes(self) -> list[nodes.Statements]:
        return self.__nodes

    @property
    def code_tokens(self) -> list[tokens.Token]:
        return self.__tokens
    
    @code_tokens.setter
    def code_tokens(self, tokens: list[tokens.Token]):
        self.__tokens = tokens

    def next_token(self):
        self.__pos += 1

    def before_token(self):
        self.__pos -= 1

    def get_token(self, offset: int = 0):
        return self.__tokens [self.__pos + offset]
    
    def get_token_signature(self, offset: int = 0) -> tokens.TokenSignature:
        return self.get_token(offset).signature
    
    def get_token_value(self, offset: int = 0) -> str:
        return self.get_token(offset).value
    
    def get_token_position(self, offset: int = 0) -> tokens.TokenPosition:
        return self.get_token(offset).position
    
    def is_token_signature(self, signature: tokens.TokenSignature, offset: int = 0) -> bool:
        return self.get_token_signature(offset) == signature
    
    def match_token_signature(self, signature: tokens.TokenSignature, offset: int = 0):
        if self.is_token_signature(signature, offset):
            self.next_token()
            return True
        return False
    
    def match_token_signatures(self, signatures: list[tokens.TokenSignature]) -> bool:
        for signature in signatures:
            if self.is_token_signature(signature):
                self.next_token()
                return True
        return False
    
    def match_and_wait(self, signature: tokens.SignatureObject, offset: int = 0):
        if self.match_token_signature(signature.signature, offset):
            ...
        else:
            luma_excepts.BaseLumaException(self.__file, luma_excepts.LumaExceptionType.PARSER, f'Waited {Fore.YELLOW}"{signature.value}"{Fore.RESET} signature')(
                tokens.TokenPosition(self.get_token_position(-1).line, self.get_token_position(-1).start + self.get_token_position(-1).lenght, 1)
            )
        
    def is_token_and_wait(self, signature: tokens.SignatureObject, offset: int = 0):
        if self.is_token_signature(signature.signature, offset):
            ...
        else:
            luma_excepts.BaseLumaException(self.__file, luma_excepts.LumaExceptionType.PARSER, f'Waited {Fore.YELLOW}"{signature.value}"{Fore.RESET} signature')(
                tokens.TokenPosition(self.get_token_position(-1).line, self.get_token_position(-1).start + self.get_token_position(-1).lenght, 1)
            )
    
    def STATEMENT_VARIABLE_SET(self):
        if self.is_token_signature(tokens.TokenSignature.KEYWORD_VAR) or self.is_token_signature(tokens.TokenSignature.KEYWORD_VAL):
            
            self.match_token_signatures([tokens.TokenSignature.KEYWORD_VAR, tokens.TokenSignature.KEYWORD_VAL])
            
            mutable = memory.MemoryObjectTypes.mutable if self.match_token_signature(tokens.TokenSignature.KEYWORD_MUT) else memory.MemoryObjectTypes.unmutable
            self.is_token_and_wait(tokens.SignatureObject(tokens.TokenSignature.WORD, 'variable name'))
            name = self.get_token_value()
            self.match_token_signature(tokens.TokenSignature.WORD)
            if self.is_token_signature(tokens.TokenSignature.OPERATOR_DOT_AND_COMMA):
                expression = None
            else:
                expression = self.parse_expression()
            self.is_token_and_wait(tokens.get_signature(';'))
            
            return nodes.Statements.NodeVariableSet(name, mutable, expression, self.__run_time_memory)
        
            

    def parse_statement(self):
        statement = self.STATEMENT_VARIABLE_SET()
        return statement
        

    def parse_expression(self):
        return ...

    def generate_ast(self):
        while self.get_token_signature() != tokens.TokenSignature.EOF:
            self.__nodes.append(self.parse_statement())
            
            self.next_token()