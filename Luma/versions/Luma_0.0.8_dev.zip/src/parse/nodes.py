from src.core import memory

class Statements:

    class NodeVariableSet:
        def __init__(self, var_name: str, var_mutable: memory.MemoryObjectTypes, var_expression, memory: memory.Memory ) -> None:
            self.__name = var_name
            self.__mutable = var_mutable
            self.__expression = var_expression
            self.__memory = memory

        def exec(self):
            ...