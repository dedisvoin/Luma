from colorama import Fore

class DebugSignatures:
    MESSAGE_DEBUG = f'[{Fore.LIGHTBLACK_EX} DEBUG {Fore.RESET}]'
    MESSAGE_TOKENIZER = f'[{Fore.LIGHTBLACK_EX} TOKENIZER {Fore.RESET}]'
    MESSAGE_LOADER = f'[{Fore.LIGHTBLACK_EX} LOADER {Fore.RESET}]'


    NO = f'[{Fore.RED} no {Fore.RESET}]'
    YES = f'[{Fore.GREEN} yes {Fore.RESET}]'
    WARNING = f'[{Fore.YELLOW} warning {Fore.RESET}]'

debug_log = False

class DebugMessage:
    def __init__(self, debug_signature: DebugSignatures) -> None:
        self.__debug_signature = debug_signature
        self.out_funct = None
        self.__messages = []

    def add_message(self, message: str):
        self.__messages.append(f'[ DEBUG ] {self.__debug_signature} {message}')

    

    def __call__(self, *args):
        for mess in self.__messages:
            print(mess)
        self.out_funct(*args)