
class LumaFile:
    def __init__(self, code: str, code_file: str, code_lenght: str) -> None:
        self.code = code
        self.code_file = code_file
        self.code_lenght = code_lenght

def LoadLumaFile(file_name: str):
    __code = ''.join(open(file_name, 'r').readlines()) + '\n'
    __code_lenght = len(__code)

    return LumaFile(__code, file_name, __code_lenght)
   