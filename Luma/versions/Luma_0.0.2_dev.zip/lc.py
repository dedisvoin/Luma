from src.analize import tokenizer, loader
from src.core import tokens
from colorama import Fore
from src.debug import tokenizer as debug_tokenizer



def print_tokens(tokens: list[tokens.Token]):
    for token in tokens:
        print(f' token: {Fore.YELLOW}{token.value:<20}{Fore.RESET} pos: {str(token.position)}')
debug_tokenizer.debug_tokens_first_stage.out_funct = print_tokens


code_file_name_ = None
code_file_ = loader.LoadLumaFile(r'compiler\main.lm')


tokenizer_ = tokenizer.Tokenizer()
tokenizer_.file = code_file_


tokenizer_.tokenize()
debug_tokenizer.debug_tokens_first_stage(tokenizer_.basic_tokens)


tokenizer_.convert_signatures()


