from src.core import memory
from src.core import luma_types
from src.core import luma_values


class BaseExpression:
    def __init__(self, file, pos) -> None:
        self.__file = file
        self.__pos = pos

    def eval(self):
        ...

class Statements:

    class NodeVariableSet:
        def __init__(self, var_name: str, var_mutable: memory.MemoryObjectTypes, var_expression, memory: memory.Memory ) -> None:
            self.__name = var_name
            self.__mutable = var_mutable
            self.__expression = var_expression
            self.__memory = memory

        def exec(self):
            ...

class Expressions:
    class NodeNumberCreate(BaseExpression):
        def __init__(self, value: str, file, pos) -> None:
            super().__init__(file, pos)
            self.__value = luma_values.LumaValue(
                luma_types.GetPyNumberForString(value), 
                luma_types.GetBaseLumaType(luma_types.GetPyNumberForString(value))
            )

        def eval(self):
            return self.__value
    
    class NodeUnareOperation(BaseExpression):
        def __init__(self, operation: str, expression, file, pos) -> None:
            super().__init__(file, pos)
            self.__operation = operation
            self.__expression = expression
        
        def eval(self):
            ...

    class NodeBinareOperation(BaseExpression):
        def __init__(self, operation: str, left_expression, right_expression, file, pos) -> None:
            super().__init__(file, pos)
            self.__operation = operation
            self.__left_expression = left_expression
            self.__right_expression = right_expression

        def eval(self):
            ...
