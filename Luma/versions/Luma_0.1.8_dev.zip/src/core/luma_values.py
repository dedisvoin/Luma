

from copy import copy
from typing import Any
from src.core import luma_types

class LumaValue:
    def __init__(self, value: Any, type: luma_types.LumaType | None = None) -> None:
        self.__value = value
        self.__type = luma_types.GetBaseLumaType(value) if type is None else type

    def get_value(self) -> Any:
        return self.__value
    
    def get_type(self) -> Any:
        return self.__type

    @classmethod
    def create(self, value: Any, type: luma_types.LumaType | None = None) -> 'LumaValue':
        return LumaValue(value, type)
    
    def copy_value(self):
        return copy(self)
    

L_True = LumaValue.create(True)
L_False = LumaValue.create(False)