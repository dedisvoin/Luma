from copy import copy

class LambdaType:
    Luma = 'Luma'
    Python = 'Python'

class LumaLambda:
    def __init__(self) -> None:
        self.__expression = None
        self.__arguments = None
        self.__type = None

    @classmethod
    def create_luma(self, expression, argumemts):
        self.__type = LambdaType.Luma
        self.__expression = expression
        self.__arguments = argumemts

        return copy(self)