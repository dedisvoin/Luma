from colorama import Fore

from src.analize import tokenizer, loader

from src.core import tokens

from src.debug import tokenizer as debug_tokenizer
from src.debug import debug


debug.set_debug_log(True)


def print_tokens(tokens: list[tokens.Token]):
    for token in tokens:
        print(f' token: {Fore.YELLOW}{token.value:<20}{Fore.RESET}      |   pos: {str(token.position):>40}   |   name: {Fore.MAGENTA}{token.signature:>30}{Fore.RESET}')
debug_tokenizer.debug_tokens_first_stage.out_funct = print_tokens
debug_tokenizer.debug_tokens_second_stage.out_funct = print_tokens


code_file_ = loader.LoadLumaFile(r'compiler\main.lm')

tokenizer_ = tokenizer.Tokenizer()
tokenizer_.file = code_file_

tokenizer_.tokenize()
debug_tokenizer.debug_tokens_first_stage(tokenizer_.basic_tokens)

tokenizer_.convert_signatures()
debug_tokenizer.debug_tokens_second_stage(tokenizer_.standert_tokens)


