def string_to_id(string: str) -> int:
    nums_and_chars_ = list(enumerate('abcdefghijklmnopqrstuvwxyz'+'abcdefghijklmnopqrstuvwxyz'.upper()))
    converted_string = ''
    for sym in string:
        for num in nums_and_chars_:
            if sym == num[1]:
                converted_string += str(num[0])
    return int(converted_string)

class LumaType:
    def __init__(self, name: str, id: int | None = None) -> None:
        self.__name = name
        self.__id = string_to_id(self.__name) if id is None else id
        
    @property
    def id(self) -> int : return self.__id

    @property
    def name(self) -> str : return self.__name

class BaseLumaTypes:
    L_String = LumaType('String')
    L_Int = LumaType('Int')
    L_Float = LumaType('Float')
    L_Bool = LumaType('Bool')
    L_Char = LumaType('Char')
    L_Function = LumaType('Function')
    L_Lambda = LumaType('Lambda')
