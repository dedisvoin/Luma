from colorama import Fore
from src.core import tokens
from src.analize import loader
import os

class LumaExceptionType:
    PARSER = f'[ {Fore.CYAN}parser{Fore.RESET} ]'
    COMPILE = f'[ {Fore.YELLOW}compile{Fore.RESET} ]'


class BaseLumaException():
    def __init__(self, file: loader.LumaFile, except_type: LumaExceptionType, text: str) -> None:
        self.__except_type = except_type
        self.__text = text
        self.__file = file

    def __call__(self, pos: tokens.TokenPosition) -> str:
        print( f'''Exception {self.__except_type} {str(pos)} 

''')
        print(f'          {self.__file.code_to_lines[pos.line]}')
        print(f'          {" " * pos.start + f"{Fore.RED}▲{Fore.RESET}" * pos.lenght}')
        print(f'          {" " * (pos.start+pos.lenght-1) + f"{Fore.RED}┃{Fore.RESET}"}')
        print(f'          {" " * (pos.start+pos.lenght-1) + f"{Fore.RED}┗{Fore.RESET}"} {Fore.RED}━━━{Fore.RESET} {self.__text}')
        os._exit(-1)


def call_exception_not_suport_operation(file, operation, value_left, value_right, pos):
    BaseLumaException(file, LumaExceptionType.COMPILE, f'The operation {Fore.YELLOW}"{operation}"{Fore.RESET} is not supported between {Fore.BLUE}<{value_left.get_type().name}>{Fore.RESET} and {Fore.BLUE}<{value_right.get_type().name}>{Fore.RESET}')(pos)