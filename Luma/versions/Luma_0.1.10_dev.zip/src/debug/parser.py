from src.debug import debug

debug_parsed_ast = debug.DebugMessage(debug.DebugSignatures.MESSAGE_PARSER)
debug_parsed_ast.add_message('Parsed ast nodes outed. '+ debug.DebugSignatures.YES)
